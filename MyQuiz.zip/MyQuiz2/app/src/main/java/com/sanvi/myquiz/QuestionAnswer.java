package com.sanvi.myquiz;

public class QuestionAnswer
{
    public static String question[]={
            "Which company owns Android",
            "which one of these is not a programming language",
            "Which one of these is a founders of Google",
            "Who is on of the founders of Apple",
            "What does the Internet Prefix WWW stand for",
            "'OS' computer Abbreviation usually means",
            "Who developed Yahoo",


    };
    public static String choices[][]=
            {

                    {"Google","Apple","Nokia","Samsung"},
                    {"Java","Kotlin","Notepad","Python"},
                    {"Sundar Pichai","Larry Page","Elon Musk","Satya Nadella"},
                    {"Larry Page","Steve Jobs","Mark Zuckerberg","Bill Gates"},
                    {"Wide Width Wickets","Worldwide Weather","Western Washington World","World Wide Web"},
                    {"Operating System","Order of Significance","Optical Sensor","Open Software"},
                    {"Dennis Ritchie and Ken Thompson","David Filo and Jerry Yang","Vint Cerf and Robert Kahn","Steve Case and Jeff Bezos"}

            };
    public static String correctAnswer[]=
            {
                    "Google",
                    "Notepad",
                    "Larry Page",
                    "Steve Jobs",
                    "World Wide Web",
                    "Operating System",
                    "David Filo and Jerry Yang",

            };


}
